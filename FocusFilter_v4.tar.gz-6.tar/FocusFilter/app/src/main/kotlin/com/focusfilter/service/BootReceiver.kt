package com.focusfilter.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.focusfilter.FocusFilterApplication
import com.focusfilter.model.FocusModeType
import com.focusfilter.util.DndManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext as FocusFilterApplication
        if (!app.preferencesManager.startOnBoot) return
        if (!app.preferencesManager.isFocusEnabled) return

        val dnd = DndManager(context)
        val modeStr = app.preferencesManager.activeModeType
        if (modeStr == FocusModeType.NONE.name) return

        CoroutineScope(Dispatchers.IO).launch {
            val mode = app.focusModeRepository.getModeByType(modeStr)
            if (mode?.dndEnabled == true) {
                dnd.enableDnd()
            }
        }
    }
}
