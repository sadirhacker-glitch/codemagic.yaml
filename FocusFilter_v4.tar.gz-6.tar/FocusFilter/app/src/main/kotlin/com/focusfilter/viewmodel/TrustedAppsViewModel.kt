package com.focusfilter.viewmodel

import android.app.Application
import android.content.pm.ApplicationInfo
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.focusfilter.FocusFilterApplication
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TrustedAppsViewModel(application: Application) : AndroidViewModel(application) {

    private val app   = application as FocusFilterApplication
    private val prefs = app.preferencesManager

    data class InstalledAppInfo(
        val packageName: String,
        val appName: String,
        val isTrusted: Boolean
    )

    private val _apps = MutableLiveData<List<InstalledAppInfo>>()
    val apps: LiveData<List<InstalledAppInfo>> = _apps

    private val _saving = MutableLiveData(false)
    val saving: LiveData<Boolean> = _saving

    private var searchQuery = ""

    init {
        loadApps()
    }

    fun loadApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm         = getApplication<Application>().packageManager
            val trusted    = prefs.trustedApps
            val installed  = pm.getInstalledApplications(0)
                .filter { info ->
                    // Exclude this app itself
                    info.packageName != app.packageName &&
                    // Only user-facing apps unless already trusted
                    (info.flags and ApplicationInfo.FLAG_SYSTEM == 0 || info.packageName in trusted)
                }
                .map { info ->
                    InstalledAppInfo(
                        packageName = info.packageName,
                        appName     = pm.getApplicationLabel(info).toString(),
                        isTrusted   = info.packageName in trusted
                    )
                }
                .sortedWith(
                    compareByDescending<InstalledAppInfo> { it.isTrusted }
                        .thenBy { it.appName.lowercase() }
                )
            _apps.postValue(applyQuery(installed, searchQuery))
        }
    }

    fun search(query: String) {
        searchQuery = query
        val current = _apps.value ?: return
        _apps.value = applyQuery(current, query)
    }

    fun toggleTrusted(packageName: String, trusted: Boolean) {
        if (trusted) prefs.addTrustedApp(packageName) else prefs.removeTrustedApp(packageName)
        // Reflect toggle immediately without a full reload, but re-apply the
        // current search query so results don't jump while the user is typing.
        val updated = _apps.value?.map { info ->
            if (info.packageName == packageName) info.copy(isTrusted = trusted) else info
        } ?: return
        _apps.value = applyQuery(updated, searchQuery)
    }

    /** Save final selection and return count of trusted apps. */
    fun trustedCount(): Int = prefs.trustedApps.size

    private fun applyQuery(list: List<InstalledAppInfo>, query: String): List<InstalledAppInfo> {
        if (query.isBlank()) return list
        val q = query.lowercase()
        return list.filter { it.appName.lowercase().contains(q) || it.packageName.contains(q) }
    }
}
