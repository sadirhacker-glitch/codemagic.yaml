package com.focusfilter.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.focusfilter.FocusFilterApplication
import com.focusfilter.R
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.model.FocusModeType
import com.focusfilter.model.NotificationAction
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

/**
 * Core notification filtering service.
 *
 * Decision pipeline (runs per notification on an IO thread):
 *
 *  0. Call category?                   → ALLOW immediately (calls are never blocked)
 *  1. Keyword safelist match?          → ALLOW immediately
 *  2. Emergency bypass active?         → ALLOW immediately, log
 *  3. SafelistManager match?           → ALLOW immediately, log
 *  4. User trusted apps list?          → ALLOW immediately, log
 *  5. AI spam gate (BERT INT8)?
 *       • spam with high confidence    → BLOCK (unless log-only)
 *       • ham / model unavailable      → continue
 *  6. Rule engine (keyword, mode default, etc.)
 *  7. ALLOW action?                    → do NOT touch the notification at all
 *  8. BLOCK / SILENT / HOLD            → cancelNotification() unless log-only
 *
 * Fail-safe: any uncaught exception → ALLOW (never silently drop a notification).
 */
class FocusFilterNotificationService : NotificationListenerService() {

    companion object {
        private const val TAG             = "FocusFilterService"
        private const val CHANNEL_SERVICE = "ff_service_channel"
        private const val NOTIF_ID_FG     = 1001

        // BUG 6: weak ref so BUG 6 allow-once check can query activeNotifications
        var instance: WeakReference<FocusFilterNotificationService>? = null
            private set
    }

    private val semanticClassifier: NotificationClassifier = SimpleClassifier()
    private val spamDetector get() = (applicationContext as FocusFilterApplication).spamDetector

    // BUG 1: start foreground immediately when the listener connects
    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = WeakReference(this)
        createServiceChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setContentTitle("FocusFilter is active")
            .setContentText("Monitoring notifications in the background")
            .setSmallIcon(R.drawable.ic_shield_small)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID_FG, notification)
        Log.i(TAG, "Listener connected — foreground service started")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        Log.i(TAG, "Listener disconnected")
    }

    // BUG 2: START_STICKY so Android auto-restarts the service after being killed
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        spamDetector // warm up lazy init
        Log.i(TAG, "FocusFilter notification service created")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.i(TAG, "FocusFilter notification service destroyed")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = applicationContext as FocusFilterApplication
        if (!app.preferencesManager.isFocusEnabled) return
        if (sbn.packageName == packageName) return

        val extras  = sbn.notification?.extras ?: return
        val title   = extras.getString("android.title") ?: ""
        val text    = extras.getCharSequence("android.text")?.toString() ?: ""
        val appName = getAppName(sbn.packageName)
        val ts      = sbn.postTime

        // BUG 2: use app-level scope so processing survives a service restart
        app.appScope.launch(Dispatchers.IO) {
            try {
                processNotification(sbn, app, title, text, appName, ts)
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error processing ${sbn.packageName} — allowing through: ${e.message}")
                logEntry(app, sbn.packageName, appName, title, text, ts,
                    app.preferencesManager.activeModeType,
                    NotificationAction.ALLOW, "error_fallback",
                    "Rule engine error — allowed as safety fallback.", isRestored = true, sbnKey = sbn.key)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}

    private suspend fun processNotification(
        sbn: StatusBarNotification,
        app: FocusFilterApplication,
        title: String,
        text: String,
        appName: String,
        ts: Long
    ) {
        val prefs         = app.preferencesManager
        val activeModeStr = prefs.activeModeType
        if (activeModeStr == FocusModeType.NONE.name) return

        val pkgName = sbn.packageName
        val logOnly = prefs.isLogOnlyMode

        // ── STEP 0: Calls — never block ──────────────────────────────────────────
        val category = sbn.notification?.category
        if (category == Notification.CATEGORY_CALL || category == Notification.CATEGORY_MISSED_CALL) {
            Log.d(TAG, "[CALL] Always allowing call notification from $pkgName")
            return
        }

        // ── STEP 1: Keyword safelist ─────────────────────────────────────────────
        val combined = "$title $text"
        if (app.keywordSafelistManager.matchesKeyword(combined)) {
            Log.d(TAG, "[KEYWORD] Allowed $pkgName — matched keyword safelist")
            allowAndReturn(app, sbn.key, pkgName, appName, title, text, ts, activeModeStr,
                "trusted", "Allowed by keyword safelist.")
            return
        }

        // ── STEP 2: Emergency bypass ─────────────────────────────────────────────
        if (prefs.isEmergencyBypassActive) {
            Log.d(TAG, "[BYPASS] Allowed $pkgName (emergency bypass active)")
            allowAndReturn(app, sbn.key, pkgName, appName, title, text, ts, activeModeStr,
                "trusted", "Emergency bypass active — all notifications passing through.")
            return
        }

        // ── STEP 3: Safelist (system, finance, comms, emergency, auth) ───────────
        val safeEntry = SafelistManager.getEntry(pkgName, packageManager)
        if (safeEntry != null) {
            Log.d(TAG, "[SAFE] ${safeEntry.tier.label} — $pkgName always allowed")
            if (safeEntry.tier != SafelistManager.ProtectionTier.SYSTEM) {
                allowAndReturn(app, sbn.key, pkgName, appName, title, text, ts, activeModeStr,
                    "important",
                    "Protected — ${safeEntry.tier.label}: ${safeEntry.reason}.")
            }
            return
        }

        // ── STEP 4: User-defined trusted apps ────────────────────────────────────
        if (prefs.isTrustedApp(pkgName)) {
            Log.d(TAG, "[TRUSTED] $appName ($pkgName) on trusted list — always allowed")
            allowAndReturn(app, sbn.key, pkgName, appName, title, text, ts, activeModeStr,
                "trusted", "$appName is on your Trusted Apps list — always allowed.")
            return
        }

        // ── STEP 5: AI spam gate ─────────────────────────────────────────────────
        var bertSaidHam = false
        if (prefs.isAiSpamDetectionEnabled) {
            val result = spamDetector.detect(combined, prefs.spamThreshold)
            if (result.modelAvailable && result.isSpam) {
                val prob = "%.0f%%".format(result.spamProbability * 100)
                Log.i(TAG, "[AI] Spam ($prob) — blocking $pkgName: \"${combined.take(60)}\"")
                val action = if (logOnly) NotificationAction.HOLD else NotificationAction.BLOCK
                if (!logOnly) cancelNotification(sbn.key)
                logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
                    action, "spam",
                    "AI detected spam ($prob confidence)${if (logOnly) " — log-only, not cancelled" else ""}.",
                    isRestored = false, sbnKey = sbn.key)
                return
            }
            bertSaidHam = result.modelAvailable
        }

        // ── STEP 6: Rule engine ──────────────────────────────────────────────────
        val rules         = app.ruleRepository.getEnabledRules()
        val rawLabel      = semanticClassifier.classify(title, text)
        val semanticLabel = if (
            prefs.isAiSpamDetectionEnabled && bertSaidHam && rawLabel == "spam"
        ) "unknown" else rawLabel

        val mode = app.focusModeRepository.getModeByType(activeModeStr)

        val actionResult = RuleEngine.resolveAction(
            pkgName       = pkgName,
            appName       = appName,
            title         = title,
            text          = text,
            label         = semanticLabel,
            rules         = rules,
            activeModeStr = activeModeStr,
            mode          = mode
        )

        // ── STEP 7: ALLOW path — do NOT touch the notification ───────────────────
        if (actionResult.action == NotificationAction.ALLOW) {
            logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
                NotificationAction.ALLOW, semanticLabel, actionResult.reason, isRestored = true)
            return
        }

        // ── STEP 8: Block / Silent / Hold ─────────────────────────────────────────
        if (!logOnly) cancelNotification(sbn.key)

        logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
            actionResult.action, semanticLabel,
            if (logOnly) "${actionResult.reason} (log-only — not cancelled)" else actionResult.reason,
            isRestored = false, sbnKey = sbn.key)
    }

    private suspend fun allowAndReturn(
        app: FocusFilterApplication,
        sbnKey: String,
        pkgName: String,
        appName: String,
        title: String,
        text: String,
        ts: Long,
        activeModeStr: String,
        label: String,
        reason: String
    ) {
        logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
            NotificationAction.ALLOW, label, reason, isRestored = true)
    }

    private suspend fun logEntry(
        app: FocusFilterApplication,
        pkgName: String,
        appName: String,
        title: String,
        text: String,
        ts: Long,
        activeModeStr: String,
        action: NotificationAction,
        label: String,
        reason: String,
        isRestored: Boolean,
        sbnKey: String? = null
    ) {
        app.notificationRepository.insert(FilteredNotification(
            packageName      = pkgName,
            appName          = appName,
            title            = title,
            text             = text,
            timestamp        = ts,
            action           = action.name,
            classifierLabel  = label,
            activeModeAtTime = activeModeStr,
            blockReason      = reason,
            isRestored       = isRestored,
            sbnKey           = sbnKey
        ))
    }

    private fun getAppName(pkgName: String): String =
        try {
            val pm   = applicationContext.packageManager
            val info = pm.getApplicationInfo(pkgName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkgName.substringAfterLast(".")
        }

    private fun createServiceChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_SERVICE,
                "FocusFilter Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps FocusFilter running in the background"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }
}
