package com.focusfilter.data.db

data class AppUsageStat(
    val packageName: String,
    val appName: String,
    val count: Int
)
