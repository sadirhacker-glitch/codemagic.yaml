package com.focusfilter.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.focusfilter.FocusFilterApplication
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.model.FocusModeType
import com.focusfilter.model.NotificationAction
import kotlinx.coroutines.*

/**
 * Core notification filtering service.
 *
 * Decision pipeline (runs per notification on an IO thread):
 *
 *  1. Emergency bypass active?         → ALLOW immediately, log
 *  2. SafelistManager match?           → ALLOW immediately, log
 *     (SYSTEM-tier prefix entries verified against FLAG_SYSTEM)
 *  3. User trusted apps list?          → ALLOW immediately, log
 *  4. AI spam gate (BERT INT8)?
 *       • spam with high confidence    → BLOCK (unless log-only)
 *       • ham / model unavailable      → continue
 *  5. Rule engine (VIP, allowed app, keyword, critical label, mode default)
 *     Note: keyword-only "spam" label is downgraded to "unknown" when BERT
 *     confirmed ham, preventing misleading log entries.
 *  6. ALLOW action?                    → do NOT touch the notification at all
 *  7. BLOCK / SILENT / HOLD            → cancelNotification() unless log-only
 *
 * Fail-safe: any uncaught exception → ALLOW (never silently drop a notification).
 */
class FocusFilterNotificationService : NotificationListenerService() {

    companion object {
        private const val TAG = "FocusFilterService"
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val semanticClassifier: NotificationClassifier = SimpleClassifier()
    private val spamDetector get() = (applicationContext as FocusFilterApplication).spamDetector

    // ── Lifecycle ────────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        spamDetector    // touch to trigger async init early
        Log.i(TAG, "FocusFilter notification service started")
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        Log.i(TAG, "FocusFilter notification service stopped")
    }

    // ── Events ───────────────────────────────────────────────────────────────────

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = applicationContext as FocusFilterApplication
        if (!app.preferencesManager.isFocusEnabled) return
        if (sbn.packageName == packageName) return

        val extras  = sbn.notification?.extras ?: return
        val title   = extras.getString("android.title") ?: ""
        val text    = extras.getCharSequence("android.text")?.toString() ?: ""
        val appName = getAppName(sbn.packageName)
        val ts      = sbn.postTime

        serviceScope.launch {
            try {
                processNotification(sbn, app, title, text, appName, ts)
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error processing ${sbn.packageName} — allowing through: ${e.message}")
                logEntry(app, sbn.packageName, appName, title, text, ts,
                    app.preferencesManager.activeModeType,
                    NotificationAction.ALLOW, "error_fallback",
                    "Rule engine error — allowed as safety fallback.", isRestored = true)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}

    // ── Main pipeline ─────────────────────────────────────────────────────────────

    private suspend fun processNotification(
        sbn: StatusBarNotification,
        app: FocusFilterApplication,
        title: String,
        text: String,
        appName: String,
        ts: Long
    ) {
        val prefs         = app.preferencesManager
        val activeModeStr = prefs.activeModeType
        if (activeModeStr == FocusModeType.NONE.name) return

        val pkgName = sbn.packageName
        val logOnly = prefs.isLogOnlyMode

        // ── STEP 1: Emergency bypass ─────────────────────────────────────────────
        if (prefs.isEmergencyBypassActive) {
            Log.d(TAG, "[BYPASS] Allowed $pkgName (emergency bypass active)")
            allowAndReturn(app, sbn.key, pkgName, appName, title, text, ts, activeModeStr,
                "trusted", "Emergency bypass active — all notifications passing through.")
            return
        }

        // ── STEP 2: Safelist (system, finance, comms, emergency, auth) ───────────
        val safeEntry = SafelistManager.getEntry(pkgName, packageManager)
        if (safeEntry != null) {
            Log.d(TAG, "[SAFE] ${safeEntry.tier.label} — $pkgName always allowed")
            if (safeEntry.tier != SafelistManager.ProtectionTier.SYSTEM) {
                // Only log non-system entries — System UI posts dozens of silent
                // background notifications per hour (battery, wallpaper, accessibility)
                // that the user never sees. Logging them inflates "Important Allowed"
                // stats with pure noise.
                allowAndReturn(app, sbn.key, pkgName, appName, title, text, ts, activeModeStr,
                    "important",
                    "✓ Protected — ${safeEntry.tier.label}: ${safeEntry.reason}.")
            }
            return
        }

        // ── STEP 3: User-defined trusted apps ────────────────────────────────────
        if (prefs.isTrustedApp(pkgName)) {
            Log.d(TAG, "[TRUSTED] $appName ($pkgName) on trusted list — always allowed")
            allowAndReturn(app, sbn.key, pkgName, appName, title, text, ts, activeModeStr,
                "trusted",
                "✓ $appName is on your Trusted Apps list — always allowed.")
            return
        }

        // ── STEP 4: AI spam gate ─────────────────────────────────────────────────
        val combined  = "$title $text"
        var bertSaidHam = false
        if (prefs.isAiSpamDetectionEnabled) {
            val result = spamDetector.detect(combined, prefs.spamThreshold)
            if (result.modelAvailable && result.isSpam) {
                val prob = "%.0f%%".format(result.spamProbability * 100)
                Log.i(TAG, "[AI] Spam ($prob) — blocking $pkgName: \"${combined.take(60)}\"")
                val action = if (logOnly) NotificationAction.HOLD else NotificationAction.BLOCK
                if (!logOnly) cancelNotification(sbn.key)
                logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
                    action, "spam",
                    "✗ AI detected spam ($prob confidence)${if (logOnly) " — log-only, not cancelled" else ""}.",
                    isRestored = false)
                return
            }
            bertSaidHam = result.modelAvailable
        }

        // ── STEP 5: Rule engine ──────────────────────────────────────────────────
        val rules = app.ruleRepository.getEnabledRules()

        // Title-weighted classify: title is checked first; body used as fallback.
        val rawLabel = semanticClassifier.classify(title, text)

        // Downgrade keyword-only "spam" to "unknown" when BERT confirmed ham —
        // prevents misleading log entries like "Spam notifications blocked" for ham.
        val semanticLabel = if (
            prefs.isAiSpamDetectionEnabled && bertSaidHam && rawLabel == "spam"
        ) "unknown" else rawLabel

        val mode = app.focusModeRepository.getModeByType(activeModeStr)

        val actionResult = RuleEngine.resolveAction(
            pkgName       = pkgName,
            appName       = appName,
            title         = title,
            text          = text,
            label         = semanticLabel,
            rules         = rules,
            activeModeStr = activeModeStr,
            mode          = mode
        )

        // ── STEP 6: ALLOW path — do NOT touch the notification ───────────────────
        // The notification has already appeared with the correct sound, banner, and
        // vibration exactly as the originating app intended. Any interference here
        // (even beyond cancel) risks breaking the user experience for allowed apps.
        if (actionResult.action == NotificationAction.ALLOW) {
            logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
                NotificationAction.ALLOW, semanticLabel, actionResult.reason, isRestored = true)
            return
        }

        // ── STEP 7: Block / Silent / Hold ────────────────────────────────────────
        if (!logOnly) cancelNotification(sbn.key)

        logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
            actionResult.action, semanticLabel,
            if (logOnly) "${actionResult.reason} (log-only — not cancelled)" else actionResult.reason,
            isRestored = false)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────────

    /** Shared helper for any passthrough-and-return path in the pipeline. */
    private suspend fun allowAndReturn(
        app: FocusFilterApplication,
        sbnKey: String,
        pkgName: String,
        appName: String,
        title: String,
        text: String,
        ts: Long,
        activeModeStr: String,
        label: String,
        reason: String
    ) {
        // Nothing to do to the notification — it stays exactly as posted.
        logEntry(app, pkgName, appName, title, text, ts, activeModeStr,
            NotificationAction.ALLOW, label, reason, isRestored = true)
    }

    private suspend fun logEntry(
        app: FocusFilterApplication,
        pkgName: String,
        appName: String,
        title: String,
        text: String,
        ts: Long,
        activeModeStr: String,
        action: NotificationAction,
        label: String,
        reason: String,
        isRestored: Boolean
    ) {
        app.notificationRepository.insert(FilteredNotification(
            packageName      = pkgName,
            appName          = appName,
            title            = title,
            text             = text,
            timestamp        = ts,
            action           = action.name,
            classifierLabel  = label,
            activeModeAtTime = activeModeStr,
            blockReason      = reason,
            isRestored       = isRestored
        ))
    }

    private fun getAppName(pkgName: String): String =
        try {
            val pm   = applicationContext.packageManager
            val info = pm.getApplicationInfo(pkgName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkgName.substringAfterLast(".")
        }
}
