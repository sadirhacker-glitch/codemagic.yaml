package com.focusfilter.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.focusfilter.FocusFilterApplication
import com.focusfilter.MainActivity
import com.focusfilter.R
import com.focusfilter.model.FocusModeType
import com.focusfilter.util.DndManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// BUG 5: reset prefs after reboot and show a re-enable notification
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val app   = context.applicationContext as FocusFilterApplication
        val prefs = app.preferencesManager

        if (!prefs.startOnBoot) return

        val wasActive   = prefs.isFocusEnabled
        val prevMode    = prefs.activeModeType

        // Always reset — the service has not reconnected yet after reboot
        prefs.isFocusEnabled  = false
        prefs.activeModeType  = FocusModeType.NONE.name

        if (wasActive && prevMode != FocusModeType.NONE.name) {
            showResumeNotification(context)

            // Still honour DND if the previous mode had it on
            val dnd = DndManager(context)
            CoroutineScope(Dispatchers.IO).launch {
                val mode = app.focusModeRepository.getModeByType(prevMode)
                if (mode?.dndEnabled == true) dnd.enableDnd()
            }
        }
    }

    private fun showResumeNotification(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "FocusFilter Alerts", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Alerts about FocusFilter state" }
            nm.createNotificationChannel(ch)
        }

        val tapIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_shield_small)
            .setContentTitle("FocusFilter was active before shutdown")
            .setContentText("Tap to resume your focus session")
            .setContentIntent(tapIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        nm.notify(NOTIF_ID_BOOT, notif)
    }

    companion object {
        private const val CHANNEL_ID    = "ff_alerts_channel"
        private const val NOTIF_ID_BOOT = 2001
    }
}
