package com.focusfilter

import android.app.Application
import android.content.ComponentCallbacks2
import com.focusfilter.data.db.AppDatabase
import com.focusfilter.data.keyword.KeywordSafelistManager
import com.focusfilter.data.repository.FocusModeRepository
import com.focusfilter.data.repository.NotificationRepository
import com.focusfilter.data.repository.RuleRepository
import com.focusfilter.service.BertSpamDetector
import com.focusfilter.util.DndManager
import com.focusfilter.util.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FocusFilterApplication : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        appScope.launch(Dispatchers.IO) {
            val fourteenDaysAgo = System.currentTimeMillis() - (14L * 24 * 60 * 60 * 1_000)
            database.filteredNotificationDao().clearNonPermanentBefore(fourteenDaysAgo)
        }
    }

    // BUG 3: release ONNX session memory when the OS is critically low on RAM
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE) {
            spamDetector.close()
        }
    }

    val database by lazy { AppDatabase.getInstance(this) }

    val notificationRepository by lazy {
        NotificationRepository(database.filteredNotificationDao())
    }
    val focusModeRepository by lazy {
        FocusModeRepository(database.focusModeDao())
    }
    val ruleRepository by lazy {
        RuleRepository(database.ruleDao())
    }

    val preferencesManager by lazy { PreferencesManager(this) }
    val dndManager by lazy { DndManager(this) }
    val keywordSafelistManager by lazy { KeywordSafelistManager(this) }

    val spamDetector: BertSpamDetector by lazy {
        BertSpamDetector(this).also { it.initAsync(appScope) }
    }
}
