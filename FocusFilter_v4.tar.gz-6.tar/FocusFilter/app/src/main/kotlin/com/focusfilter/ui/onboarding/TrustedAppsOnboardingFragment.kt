package com.focusfilter.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.focusfilter.FocusFilterApplication
import com.focusfilter.adapter.AppSelectionAdapter
import com.focusfilter.databinding.FragmentTrustedAppsOnboardingBinding
import com.focusfilter.viewmodel.TrustedAppsViewModel

/**
 * First-time onboarding screen for Trusted Apps.
 *
 * Shown when the user has not yet configured trusted apps. After tapping "Done",
 * a preference flag is set so the onboarding is not shown again; the user can
 * revisit and edit from Settings → Trusted Apps anytime.
 */
class TrustedAppsOnboardingFragment : Fragment() {

    private var _binding: FragmentTrustedAppsOnboardingBinding? = null
    private val binding get() = _binding!!
    private val vm: TrustedAppsViewModel by viewModels()
    private lateinit var adapter: AppSelectionAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTrustedAppsOnboardingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupSearch()
        setupObservers()

        binding.btnDone.setOnClickListener {
            val app = requireContext().applicationContext as FocusFilterApplication
            // Mark onboarding complete — this screen will not be shown again.
            // The user can revisit anytime via Settings → Trusted Apps.
            app.preferencesManager.hasCompletedOnboarding = true
            findNavController().popBackStack()
        }
    }

    private fun setupRecyclerView() {
        adapter = AppSelectionAdapter { packageName, trusted ->
            vm.toggleTrusted(packageName, trusted)
        }

        binding.rvApps.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = this@TrustedAppsOnboardingFragment.adapter
            addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener { text ->
            vm.search(text?.toString() ?: "")
        }
    }

    private fun setupObservers() {
        vm.apps.observe(viewLifecycleOwner) { apps ->
            adapter.submitList(apps)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
