package com.focusfilter.util

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings

class DndManager(private val context: Context) {

    private val nm: NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    val hasPermission: Boolean
        get() = nm.isNotificationPolicyAccessGranted

    val isDndActive: Boolean
        get() = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL

    val currentFilter: Int
        get() = nm.currentInterruptionFilter

    fun enableDnd(silenceCalls: Boolean = false) {
        if (!hasPermission) return
        if (silenceCalls) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        } else {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
    }

    fun disableDnd() {
        if (!hasPermission) return
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
    }

    fun setDnd(enabled: Boolean, silenceCalls: Boolean = false) {
        if (enabled) enableDnd(silenceCalls) else disableDnd()
    }

    fun openDndSettings() {
        val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
