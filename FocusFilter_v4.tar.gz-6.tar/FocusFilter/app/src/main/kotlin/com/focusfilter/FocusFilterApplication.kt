package com.focusfilter

import android.app.Application
import com.focusfilter.data.db.AppDatabase
import com.focusfilter.data.repository.FocusModeRepository
import com.focusfilter.data.repository.NotificationRepository
import com.focusfilter.data.repository.RuleRepository
import com.focusfilter.service.BertSpamDetector
import com.focusfilter.util.DndManager
import com.focusfilter.util.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FocusFilterApplication : Application() {

    /** Application-wide coroutine scope — lives as long as the process. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        // Auto-clear non-permanent inbox entries older than 14 days on every startup.
        appScope.launch(Dispatchers.IO) {
            val fourteenDaysAgo = System.currentTimeMillis() - (14L * 24 * 60 * 60 * 1_000)
            database.filteredNotificationDao().clearNonPermanentBefore(fourteenDaysAgo)
        }
    }

    val database by lazy { AppDatabase.getInstance(this) }

    val notificationRepository by lazy {
        NotificationRepository(database.filteredNotificationDao())
    }
    val focusModeRepository by lazy {
        FocusModeRepository(database.focusModeDao())
    }
    val ruleRepository by lazy {
        RuleRepository(database.ruleDao())
    }

    val preferencesManager by lazy { PreferencesManager(this) }
    val dndManager by lazy { DndManager(this) }

    /**
     * Shared BERT spam detector — owned by the Application so the ONNX session is
     * loaded once and reused across service restarts.
     * Initialisation runs asynchronously on [appScope]; callers check [BertSpamDetector.isModelLoaded].
     */
    val spamDetector: BertSpamDetector by lazy {
        BertSpamDetector(this).also { it.initAsync(appScope) }
    }
}
